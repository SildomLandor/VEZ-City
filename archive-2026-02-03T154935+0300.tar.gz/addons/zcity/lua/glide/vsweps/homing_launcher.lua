VSWEP.Base = "missile_launcher"
VSWEP.Name = "#glide.weapons.homing_missiles"
VSWEP.Icon = "glide/icons/rocket.png"

if SERVER then
    VSWEP.FireDelay = 1
    VSWEP.EnableLockOn = true
end
