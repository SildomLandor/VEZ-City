-- ehh когда нибудь...
local PANEL = {}

function PANEL:Init()
    self:SetSize(ScrW()/4, ScrH())
end