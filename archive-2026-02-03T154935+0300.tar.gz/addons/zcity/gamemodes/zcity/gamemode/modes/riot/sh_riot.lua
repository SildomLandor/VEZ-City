local MODE = MODE

zb = zb or {}
zb.Points = zb.Points or {}

zb.Points.RIOT_TDM_LAW = zb.Points.RIOT_TDM_LAW or {}
zb.Points.RIOT_TDM_LAW.Color = Color(0,0,150)
zb.Points.RIOT_TDM_LAW.Name = "RIOT_TDM_LAW"

zb.Points.RIOT_TDM_RIOTERS = zb.Points.RIOT_TDM_RIOTERS or {}
zb.Points.RIOT_TDM_RIOTERS.Color = Color(150,95,0)
zb.Points.RIOT_TDM_RIOTERS.Name = "RIOT_TDM_RIOTERS"

