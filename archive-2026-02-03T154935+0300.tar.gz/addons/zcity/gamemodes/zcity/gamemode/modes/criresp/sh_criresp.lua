local MODE = MODE

zb = zb or {}
zb.Points = zb.Points or {}

zb.Points.HMCD_CRI_CT = zb.Points.HMCD_CRI_CT or {}
zb.Points.HMCD_CRI_CT.Color = Color(0,0,150)
zb.Points.HMCD_CRI_CT.Name = "HMCD_CRI_CT"

zb.Points.HMCD_CRI_T = zb.Points.HMCD_CRI_T or {}
zb.Points.HMCD_CRI_T.Color = Color(237,13,13)
zb.Points.HMCD_CRI_T.Name = "HMCD_CRI_T"