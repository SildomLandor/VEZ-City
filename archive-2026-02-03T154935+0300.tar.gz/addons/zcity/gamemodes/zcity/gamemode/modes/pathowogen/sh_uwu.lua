local MODE = MODE

MODE.name = "pathowogen"
MODE.PrintName = "Pathowogen :3"

zb = zb or {}
zb.Points = zb.Points or {}

zb.Points.HELI_EVAC = zb.Points.HELI_EVAC or {}
zb.Points.HELI_EVAC.Color = Color(255, 165, 0) 
zb.Points.HELI_EVAC.Name = "HELI_EVAC"
zb.Points.HELI_EVAC.Points = zb.Points.HELI_EVAC.Points or {}

zb.Points.UWU_GlideHeli = zb.Points.UWU_GlideHeli or {}
zb.Points.UWU_GlideHeli.Color = Color(255, 85, 0)
zb.Points.UWU_GlideHeli.Name = "Pathowogen Helicopter"
zb.Points.UWU_GlideHeli.Points = zb.Points.UWU_GlideHeli.Points or {}

zb.Points.UWU_DeltaSquad = zb.Points.UWU_DeltaSquad or {}
zb.Points.UWU_DeltaSquad.Color = Color(255, 208, 0)
zb.Points.UWU_DeltaSquad.Name = "Pathowogen Delta Squad"
zb.Points.UWU_DeltaSquad.Points = zb.Points.UWU_DeltaSquad.Points or {}

