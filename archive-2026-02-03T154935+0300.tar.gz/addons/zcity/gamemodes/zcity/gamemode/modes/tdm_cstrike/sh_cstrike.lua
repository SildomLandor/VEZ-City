local MODE = MODE

MODE.base = "tdm"

MODE.PrintName = "Counter-Strike"
MODE.name = "cstrike"

zb.Points.BOMB_ZONE_A = zb.Points.BOMB_ZONE_A or {}
zb.Points.BOMB_ZONE_A.Color = Color(0,50,70)
zb.Points.BOMB_ZONE_A.Name = "BOMB_ZONE_A"

zb.Points.BOMB_ZONE_B = zb.Points.BOMB_ZONE_B or {}
zb.Points.BOMB_ZONE_B.Color = Color(70,50,0)
zb.Points.BOMB_ZONE_B.Name = "BOMB_ZONE_B"

zb.Points.HOSTAGE_DELIVERY_ZONE = zb.Points.HOSTAGE_DELIVERY_ZONE or {}
zb.Points.HOSTAGE_DELIVERY_ZONE.Color = Color(150,150,150)
zb.Points.HOSTAGE_DELIVERY_ZONE.Name = "HOSTAGE_DELIVERY_ZONE"