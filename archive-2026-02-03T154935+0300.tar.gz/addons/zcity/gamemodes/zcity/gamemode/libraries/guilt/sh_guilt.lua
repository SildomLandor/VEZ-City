zb = zb or {}
zb.MaximumHarm = 10
zb.MaxKarma = 120